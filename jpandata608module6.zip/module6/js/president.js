var dataOfPresidents;
d3.csv("data/presidents.csv",  function(error, data) 
{
	dataOfPresidents = data;	
	var presitable = document.createElement("table");
	var headerRow = presitable.insertRow(-1);//header
	//For Headers
	var name = headerRow.insertCell(0);
	var height = headerRow.insertCell(1);
	var weight = headerRow.insertCell(2);
	name.innerHTML = "Name Of President";
	height.innerHTML = "Height Of President";
    weight.innerHTML = "Weight Of President";
	name.style.fontWeight="bold";
	height.style.fontWeight="bold";
	weight.style.fontWeight="bold";
	//president Data
	for(var i=0; i<dataOfPresidents.length; i++) 
	{
		var dataRow = presitable.insertRow(-1);        
        dataRow.insertCell(0).innerHTML = dataOfPresidents[i].Name;
        dataRow.insertCell(1).innerHTML = dataOfPresidents[i].Height;
        dataRow.insertCell(2).innerHTML = dataOfPresidents[i].Weight;
    }
    document.getElementById("presidentialTable").appendChild(presitable);
});
info = function()
{
	var president=document.getElementById("president").value;
	var info="";
	for(var i=0; i<dataOfPresidents.length; i++) 
	{
		if(president==dataOfPresidents[i].Name)
		{
			 info=dataOfPresidents[i].Name + ' is ' +  dataOfPresidents[i].Height + ' inches tall  and  has weight of ' + dataOfPresidents[i].Weight + ' lbs.'
		}
	}
	document.getElementById("info").innerHTML = info;
}
