var dataOftrees;
d3.json("https://data.cityofnewyork.us/resource/nwxe-4ae8.json?$limit=5000&$select=spc_common,health,count(spc_common),boroname&$group=spc_common,health,boroname",  function(error, data)
{
	dataOftrees = data;//got trees data
	var treestable = document.createElement("table");
	var headerRow = treestable.insertRow(-1);//header
	//For Headers
	var boroname = headerRow.insertCell(0);
	var count_spc_common = headerRow.insertCell(1);
	var health = headerRow.insertCell(2);
	var spc_common = headerRow.insertCell(3);
	boroname.innerHTML = "Name Of Boro";
	count_spc_common.innerHTML = "Count of Species";
	health.innerHTML = "Helath";
    spc_common.innerHTML = "Species Name";
    //style
	boroname.style.fontWeight="bold";
	count_spc_common.style.fontWeight="bold";
	health.style.fontWeight="bold";
	spc_common.style.fontWeight="bold";
	for(var i=0; i<dataOftrees.length; i++) 
	{	
		var dataRow = treestable.insertRow(-1);        
        dataRow.insertCell(0).innerHTML = dataOftrees[i].boroname;
        dataRow.insertCell(1).innerHTML = dataOftrees[i].count_spc_common;
        dataRow.insertCell(2).innerHTML = dataOftrees[i].health;
        dataRow.insertCell(3).innerHTML = dataOftrees[i].spc_common;
	}
	document.getElementById("treesTable").appendChild(treestable);
}
);
info = function()
{
	var tree=document.getElementById("species").value;
	var info="";
	for(var i=0; i<dataOftrees.length; i++) 
	{
		if(tree==dataOftrees[i].spc_common)
		{
			 info = dataOftrees[i].spc_common + ' has ' + dataOftrees[i].count_spc_common + ' plants in ' +dataOftrees[i].health + ' health in ' + dataOftrees[i].boroname +'.<br>';
			 //info=dataOfPresidents[i].Name + ' is ' +  dataOfPresidents[i].Height + ' inches tall  and  has weight of ' + dataOfPresidents[i].Weight + ' lbs.'
		}
	}
	document.getElementById("info").innerHTML = info;
}
