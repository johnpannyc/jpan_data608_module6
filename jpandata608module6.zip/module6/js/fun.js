function revStr(input)//fucntion for reversing a string
{
	return input.split("").reverse().join("");
}
